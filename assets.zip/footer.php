<?php
/**
 * @package web-rtpslot
 * @since 1.0.0
 */
?>

        <?php get_component( 'footer' ); ?>
    </body>
</html>
