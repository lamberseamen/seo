<?php
/**
 * @package web-rtpslot
 * @since 1.0.0
 */

require_once './functions.php';

get_header();
get_component( 'content' );
get_footer();
