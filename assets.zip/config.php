<?php
/**
 * @package web-rtpslot
 * @since 1.0.0
 */

global $meta, $link;

$meta = (object)[
    'title' => 'RTP Wikatogel : Bocoran RTP Live Hari Ini 99% Paling Akurat',
    'description' => 'Selamat datang di RTP Wikatogel sebagai bocoran RTP Live Hari ini yang bisa memberikan angka paling akurat hingga mencapai angka 99% juga diupdate secara berkala.',
    'keywords' => 'rtp wikatogel',
    'author' => 'WIKATOGEL',
];

$link = (object)[
    'base'     => 'https://wika.livedraw.workers.dev',
    'login'    => 'https://wika.livedraw.workers.dev',
    'daftar'   => 'https://wika.livedraw.workers.dev',
    'promosi'  => 'https://wika.livedraw.workers.dev',
    'whatsapp' => 'https://rebrand.ly/WAWIKA',
    'livechat' => 'https://wika.livedraw.workers.dev',
];
